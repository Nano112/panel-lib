package dev.harrison.panellib.mixin;

import net.minecraft.class_1041;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Lets GameViewport drive Minecraft's own resize path with a spoofed framebuffer size. */
@Mixin(class_1041.class)
public interface WindowAccessor {
    @Invoker("onFramebufferResize")
    void panellib$onFramebufferResize(long window, int width, int height);
}

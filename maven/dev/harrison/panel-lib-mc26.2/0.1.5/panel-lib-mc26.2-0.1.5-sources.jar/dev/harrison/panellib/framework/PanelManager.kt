package dev.harrison.panellib.framework

import dev.harrison.panellib.core.PanelController
import dev.harrison.panellib.core.PanelSpec
import imgui.ImGui
import imgui.type.ImBoolean

/**
 * Open-panel state in z/insertion order, plus the per-frame begin/end wrapper around each
 * panel's content. Pure state operations are unit-tested; [renderAll] needs ImGui.
 */
object PanelManager : PanelController {
    private val open = LinkedHashMap<String, PanelSpec>()
    private val openFlag = ImBoolean(true)
    /** Panels that have been submitted at least once this session (ini-less first show → dock to the side node). */
    private val shownOnce = HashSet<String>()
    /** Panels still within their first frames after opening: keep them inside the game window (no auto-detach). */
    private val settling = HashMap<String, Int>()

    override fun isOpen(id: String): Boolean = open.containsKey(id)
    override fun open(panel: PanelSpec) {
        PanelLibLog.LOGGER.debug("[panel-lib] open panel {}", panel.id)
        open.putIfAbsent(panel.id, panel); Overlay.ensureOpen()
    }
    override fun close(id: String) {
        val panel = open.remove(id) ?: return
        settling.remove(id)
        runCatching { panel.notifyClosed() }.onFailure { PanelLibLog.LOGGER.error("Panel close listener failed for {}", id, it) }
    }
    override fun toggle(panel: PanelSpec) { if (isOpen(panel.id)) close(panel.id) else open(panel) }
    fun anyOpen(): Boolean = open.isNotEmpty()
    fun openPanels(): List<PanelSpec> = open.values.toList()
    fun closeAll() = open.keys.toList().forEach(::close)
    fun closeTop() { open.keys.lastOrNull()?.let(::close) }

    /** Visible for tests: reset all state. */
    internal fun reset() = open.clear()

    /** Clamp a freshly shown floating window inside the game window so it never starts as an external window. */
    private fun settle(panel: PanelSpec, frames: Int) {
        if (!ImGui.isWindowDocked()) ImGui.getMainViewport()?.let { mv ->
            val x = ImGui.getWindowPosX(); val y = ImGui.getWindowPosY(); val w = ImGui.getWindowWidth(); val h = ImGui.getWindowHeight()
            val nx = x.coerceIn(mv.posX, maxOf(mv.posX, mv.posX + mv.sizeX - w)); val ny = y.coerceIn(mv.posY, maxOf(mv.posY, mv.posY + mv.sizeY - h))
            PanelLibLog.LOGGER.debug("[panel-lib] settle {}: pos=({},{}) size=({},{}) main=({},{} {}x{}) -> ({},{})", panel.id, x, y, w, h, mv.posX, mv.posY, mv.sizeX, mv.sizeY, nx, ny)
            if (nx != x || ny != y) ImGui.setWindowPos(nx, ny)
        }
        if (frames <= 1) settling.remove(panel.id) else settling[panel.id] = frames - 1
    }

    fun renderAll() {
        for (panel in open.values.toList()) {
            openFlag.set(true)
            if (shownOnce.add(panel.id)) {
                // FirstUseEver: a window with saved ini settings keeps them; a brand-new one docks to the side.
                val side = DockHost.sideNodeId()
                if (side != 0) imgui.internal.ImGui.setNextWindowDockID(side, imgui.flag.ImGuiCond.FirstUseEver)
                settling[panel.id] = 3
            }
            // A panel never starts detached: while settling, pin it to the game window's viewport. (Raw panels do
            // their own begin; the pin still applies to their next window.)
            val settleFrames = settling[panel.id]
            if (settleFrames != null && ImGuiManager.viewportsActive) ImGui.getMainViewport()?.let { ImGui.setNextWindowViewport(it.id) }
            if (!panel.managed) {
                // Raw panel: the consumer owns begin/end and closes itself through its handle.
                try { panel.render() } catch (t: Throwable) {
                    PanelLibLog.LOGGER.error("[panel-lib] raw panel '{}' threw; closing it", panel.id, t); close(panel.id)
                }
                continue
            }
            val shown = ImGui.begin(panel.windowLabel, openFlag, panel.flags)
            if (settleFrames != null) settle(panel, settleFrames)
            try {
                if (shown) {
                    try { panel.render() } catch (t: Throwable) { PanelErrors.render(panel, t) }
                }
            } finally {
                ImGui.end()
            }
            if (!openFlag.get()) { PanelLibLog.LOGGER.debug("[panel-lib] panel {} closed via title bar (shown={})", panel.id, shown); close(panel.id) }
        }
    }
}

/** A panel whose render threw shows the error instead of taking the whole overlay down. */
internal object PanelErrors {
    private val seen = HashMap<String, Throwable>()
    fun render(panel: PanelSpec, t: Throwable) {
        if (seen.put(panel.id, t) == null) PanelLibLog.LOGGER.error("[panel-lib] panel '{}' threw", panel.id, t)
        val th = dev.harrison.panellib.theme.Theme.current
        ImGui.textColored(th.danger.x, th.danger.y, th.danger.z, th.danger.w, "Panel error: ${t::class.java.simpleName}")
        ImGui.textWrapped(t.message ?: "")
    }
}

internal object PanelLibLog { val LOGGER = org.slf4j.LoggerFactory.getLogger("panellib") }
